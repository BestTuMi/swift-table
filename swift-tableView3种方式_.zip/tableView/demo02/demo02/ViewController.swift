//
//  ViewController.swift
//  demo02
//
//  Created by Demon on 16/8/8.
//  Copyright © 2016年 Demon. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

