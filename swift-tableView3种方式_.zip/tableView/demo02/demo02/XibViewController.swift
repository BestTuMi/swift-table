//
//  XibViewController.swift
//  demo02
//
//  Created by Demon on 16/8/16.
//  Copyright © 2016年 Demon. All rights reserved.
//

import UIKit

class XibViewController: UIViewController {

    @IBOutlet var tableView: UITableView!
    
    var data = [
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        
        ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nibName:UINib = UINib(nibName: "XibTableViewCell", bundle: nil)
        tableView.registerNib(nibName, forCellReuseIdentifier: "XibTableViewCell")
        self.view.addSubview(tableView)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - TableView
    public func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return data.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell:XibTableViewCell = tableView.dequeueReusableCellWithIdentifier("XibTableViewCell") as! XibTableViewCell
        cell.label.text = data[indexPath.row]
        cell.img.image = UIImage(named: "image")
        cell.img.layer.masksToBounds = true
        return cell
    }
    
    
    // MARK: - TableDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        print(indexPath.row)
        
    }
    public func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        
        return 120
    }
}
