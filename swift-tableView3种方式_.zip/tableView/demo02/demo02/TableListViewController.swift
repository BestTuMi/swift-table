//
//  TableListViewController.swift
//  demo02
//
//  Created by Demon on 16/8/16.
//  Copyright © 2016年 Demon. All rights reserved.
//

import UIKit

class TableListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    var data = [
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        "这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦","这是测试数据哦",
        
        ]
    
    var tableView:UITableView = UITableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView = UITableView(frame: UIScreen.mainScreen().bounds, style: UITableViewStyle.Grouped)
        tableView.delegate = self
        tableView.dataSource = self
        self.view.addSubview(tableView)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - TableView   
    public func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return data.count
    }
   
    
    public  func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var ide = "cell"
        let cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: ide)
        cell.imageView?.image = UIImage(named: "image")
        cell.textLabel?.text = data[indexPath.row]
        cell.detailTextLabel?.text = "详情"
            
        return cell
    }
    
    // MARK: - TableDelegate
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        print(indexPath.row)
   
    }
}
